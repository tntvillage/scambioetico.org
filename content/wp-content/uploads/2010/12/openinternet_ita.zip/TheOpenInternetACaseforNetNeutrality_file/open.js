var open={};open.main={windowTop:'',noteTimeout:200,notes:["Gli ISP ti forniscono l'accesso ad Internet. Tu puoi usarlo quanto vuoi, per qualsiasi cosa desideri.","Mentre gli ISP possono limitare la tua velocita' di navigazione, essi lo fanno principalmente per rallentare i download illegali.","Tutti i tuoi dati passano attraverso una singola connessione e ti viene addebitata una tariffa mensile.","Gli ISP vogliono gestire l'accesso ad Internet e farti pagare a seconda dell'uso che ne fai.","Questo significa che AT&T o Comcast possono bloccare un servizio come Google Maps e addebitartelo separatamente."],toolbarVisible:true,init:function()
{var $this=open.main;$this.checkScroll();},hideToolbar:function()
{var $this=open.main,height=(($('#message').outerHeight())*-1);$this.toolbarVisible=false;$('#message').animate({bottom:height},50);if(document.documentElement.scrollTop){$this.windowTop=document.documentElement.scrollTop;}
else{$this.windowTop=window.pageYOffset;}},showToolbar:function()
{var $this=open.main;if($this.toolbarVisible===false){$this.toolbarVisible=true;$('#message').animate({'bottom':0},50);}},detectScrolling:function(callback)
{var $this=open.main,newWindowTop='';if(document.documentElement.scrollTop){newWindowTop=document.documentElement.scrollTop;}
else{newWindowTop=window.pageYOffset;}
if(newWindowTop!==$this.windowTop)
{$this.windowTop=newWindowTop;}
callback();},checkScroll:function()
{var $this=open.main;setTimeout(function()
{open.main.detectScrolling(function()
{open.main.checkScroll();$this.callPageNote($this.windowTop);});},$this.noteTimeout);},callPageNote:function(scrollpos)
{var $this=open.main;if(scrollpos<1300)
{$this.hideToolbar();$('#message').removeClass('green');$('#message').html('<p><a href="#">Passa parola su Twitter �</a> e salva l&#8217;Internet aperta.</p>');}
else if((scrollpos>1300)&&(scrollpos<2300))
{$('#message').removeClass('green');$this.displayPageNote(0);}
else if((scrollpos>2300)&&(scrollpos<3700))
{$('#message').addClass('green');$this.displayPageNote(1);}
else if((scrollpos>3700)&&(scrollpos<4600))
{$('#message').removeClass('green');$this.displayPageNote(2);}
else if((scrollpos>4600)&&(scrollpos<6650))
{$this.hideToolbar();}
else if((scrollpos>6650)&&(scrollpos<7900))
{$('#message').removeClass('green');$this.displayPageNote(3);}
else if((scrollpos>7900)&&(scrollpos<10000))
{$('#message').addClass('green');$this.displayPageNote(4);}
else if(scrollpos>10000)
{$this.showToolbar();$('#message').removeClass('green');$('#message').html('<p><a href="http://twitter.com/home?status=Una guida visiva alla Net Neutrality" title="Tweetta questo Sito">Passa parola su Twitter &#187;</a> e salva l&#8217;Internet aperta.</p>');}
else
{$this.hideToolbar();$('#message').removeClass('green');}},displayPageNote:function(elementId)
{var $this=open.main;$this.showToolbar();$('#message').html('<p>'+$this.notes[elementId]+'</p>');}};$(document).ready(function(){open.main.init();});